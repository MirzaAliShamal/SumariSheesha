

<?php $__env->startSection("title", "Brand"); ?>

<?php $__env->startSection("nav-title", "Brand"); ?>

<?php $__env->startSection("content"); ?>


<ul class="breadcrumb breadcrumb-style ">
    <li class="breadcrumb-item">
        <h4 class="page-title m-b-0">Brand</h4>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-home"></i></a>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.brand.list')); ?>">Brand</a>
    </li>
    <li class="breadcrumb-item active">Add</li>
</ul>

<div class="col-12">
    <div class="card mt-5">
        <div class="card-header">
            <h4>ADD Brand</h4>
        </div>
        <form action="<?php echo e(route('admin.brand.save')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label> Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Brand Name" id="name" required="">
                </div>
                <div class="form-group">
                    <label> Email</label>
                    <input type="email" class="form-control" name="email" placeholder="Brand Email" id="email" required="">
                </div>
                <input type="hidden" name="location_lat" id="location_lat">
                <input type="hidden" name="location_long" id="location_long">
                <div class="form-group">
                    <label> Phone</label>
                    <input type="number" class="form-control" name="phone" placeholder="Brand Phone" id="phone" >
                </div>
                <div class="form-group">
                    <label> Location</label>
                    <input type="text" class="form-control" name="location" id="location" >
                </div>
            </div>
            <div class="card-footer text-right">
                <button class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
     function initMap() {

        const input = document.getElementById("location");
        const options = {
            // componentRestrictions: { country: "us" },
            fields: ["formatted_address", "geometry", "name"],
            strictBounds: false,
            types: ["establishment"],
        };
        const autocomplete = new google.maps.places.Autocomplete(input, options);
        // Bind the map's bounds (viewport) property to the autocomplete object,
        // so that the autocomplete requests use the current map bounds for the
        // bounds option in the request.

        autocomplete.addListener("place_changed", () => {
            const place = autocomplete.getPlace();
            console.log(place.geometry.location.lat());

            if (!place.geometry || !place.geometry.location) {
                // User entered the name of a Place that was not suggested and
                // pressed the Enter key, or the Place Details request failed.
                window.alert("No details available for input: '" + place.name + "'");
                return;
            }
            // If the place has a geometry, then present it on a map.
            document.getElementById('location_lat').value = place.geometry.location.lat();
            document.getElementById('location_long').value = place.geometry.location.lng();
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/admin/brand/add.blade.php ENDPATH**/ ?>