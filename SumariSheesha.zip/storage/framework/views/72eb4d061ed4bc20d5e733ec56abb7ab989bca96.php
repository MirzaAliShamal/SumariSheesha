<?php if(Cart::instance('booking')->content()->count() > 0): ?>
    <?php if(auth()->user()): ?>
        <a class="button" href="<?php echo e(route('user.booking.checkout')); ?>" title="Checkout ">
            Checkout
        </a>
    <?php else: ?>
        <a class="button" href="<?php echo e(route('login')); ?>" title="Checkout">
            Checkout
        </a>
    <?php endif; ?>
<?php else: ?>
    <a class="button" href="" title="Checkout">
        Checkout
    </a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/ajax/booking_cart_footer.blade.php ENDPATH**/ ?>