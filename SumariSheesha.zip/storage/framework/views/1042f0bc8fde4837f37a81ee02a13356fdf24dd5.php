<?php $__env->startSection("title", "Product"); ?>

<?php $__env->startSection("nav-title", "Product"); ?>

<?php $__env->startSection("content"); ?>


<ul class="breadcrumb breadcrumb-style ">
    <li class="breadcrumb-item">
        <h4 class="page-title m-b-0">Product</h4>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-home"></i></a>
    </li>
    <li class="breadcrumb-item active">Product</li>
</ul>
<div class="container mb-2 text-right">
    <a href="<?php echo e(route('admin.brand_product.add')); ?>" class="btn btn-primary">Add Product</a>
</div>
<div class="col-12">
    <div class="card">
        <div class="card-header">
            <h4>Product</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="datatables table table-bordered">
                    <thead>
                        <tr>
                            <th>Product code</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Brand</th>
                            <th>Flavour</th>
                            <th>Color</th>
                            <th>Price(GBP)</th>
                            <th style="width: 2%">Status</th>
                            <th class="text-right" style="width: 20%">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><b>#SSBP<?php echo e($item->uuid); ?></b></td>
                            <td>
                                <div style="height: 50px; width:50px">
                                    <?php if($item->image): ?>
                                        <img src="<?php echo e(asset($item->image)); ?>" style="width: 100%; height:100%; object-fit:cover" alt="">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('uploads/products/empty.png')); ?>" class="rounded mr-75" alt="product image"  style="height:100%; width:100%; object-fit: cover">
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->category->name); ?></td>
                            <td><?php echo e($item->brand->name); ?></td>
                            <td><?php echo e($item->flavour ? $item->flavour->name : 'N/A'); ?> </td>
                            <td><?php echo e($item->color ? $item->color->name : 'N/A'); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <?php if($item->status): ?>
                                <td>
                                    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                                        <div class="badge-outline col-cyan">Available</div>
                                    </div>
                                </td>
                            <?php else: ?>
                            <td>
                                <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                                    <div class="badge-outline col-red">Unvailable</div>
                                </div>
                            </td>
                            <?php endif; ?>
                            <td class="text-right">
                                <button onclick="deleteAlert('<?php echo e(route('admin.brand_product.delete',$item->id)); ?>')" class="btn btn-danger btn-sm" title="delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <a href="<?php echo e(route('admin.brand_product.edit',$item->id)); ?>" class="btn btn-success btn-sm" title="edit">
                                    <i class="far fa-edit"></i>
                                </a>
                                <?php if($item->status): ?>
                                    <button onclick="alertMessage('<?php echo e(route('admin.brand_product.status',$item->id)); ?>')" class="btn btn-info btn-sm" title="Change Status">
                                        <i class="far fa-check-circle"></i>
                                    </button>
                                <?php else: ?>
                                    <button onclick="alertMessage('<?php echo e(route('admin.brand_product.status',$item->id)); ?>')" class="btn btn-warning btn-sm" title="Change Status">
                                        <i class="fas fa-times"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/admin/brand_product/list.blade.php ENDPATH**/ ?>