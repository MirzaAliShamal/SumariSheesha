

<?php $__env->startSection("title", "Flavour"); ?>

<?php $__env->startSection("nav-title", "Flavour"); ?>

<?php $__env->startSection("content"); ?>


<ul class="breadcrumb breadcrumb-style ">
    <li class="breadcrumb-item">
        <h4 class="page-title m-b-0">Flavour</h4>
    </li>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-home"></i></a>
    </li>
    <li class="breadcrumb-item active">Flavour</li>
</ul>
<div class="container mb-2 text-right">
    <a href="<?php echo e(route('admin.flavour.add')); ?>" class="btn btn-primary">Add Flavour</a>
</div>
<div class="col-12">
    <div class="card">
        <div class="card-header">
            <h4>Flavours</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="datatables table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center" width="20px">
                                #
                            </th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th class="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <?php if($item->status): ?>
                                <td>
                                    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                                        <div class="badge-outline col-cyan">Available</div>
                                    </div>
                                </td>
                            <?php else: ?>
                            <td>
                                <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                                    <div class="badge-outline col-red">Unvailable</div>
                                </div>
                            </td>
                            <?php endif; ?>
                            <td class="text-right">
                                <button onclick="deleteAlert('<?php echo e(route('admin.flavour.delete',$item->id)); ?>')" class="btn btn-danger " title="delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <a href="<?php echo e(route('admin.flavour.edit',$item->id)); ?>" class="btn btn-success " title="edit">
                                    <i class="far fa-edit"></i>
                                </a>
                                <?php if($item->status): ?>
                                    <button onclick="alertMessage('<?php echo e(route('admin.flavour.status',$item->id)); ?>')" class="btn btn-info" title="Change Status">
                                        <i class="far fa-check-circle"></i>
                                    </button>
                                <?php else: ?>
                                    <button onclick="alertMessage('<?php echo e(route('admin.flavour.status',$item->id)); ?>')" class="btn btn-warning" title="Change Status">
                                        <i class="fas fa-times"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/admin/flavour/list.blade.php ENDPATH**/ ?>