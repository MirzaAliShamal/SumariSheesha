<header class="topnav">
    <div class="container">
        <div class="d-flex align-items-center">
            <div class="logo">
                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('theme/images/logo.png')); ?>" class="img-fluid"
                        alt="Logo"></a>
            </div>
            <div class="navigation ms-auto">
                <ul class="nav">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('products')); ?>">Products</a></li>
                    <li><a href="">About</a></li>
                    <li><a href="<?php echo e(route('booking.for.delivery')); ?>">Booking for delivery</a></li>
                </ul>
                <a href="<?php echo e(route('login')); ?>" class="button button-sm">Login</a>
                <span class="cart"><i class="fal fa-shopping-cart"></i></span>
                <div class="shopping-cart">
                    <div class="shopping-cart-header d-flex">
                        <i class="far fa-cart-plus"></i>
                        <div class="shopping-cart-total ms-auto">
                            <small>Total:</small>
                            £ <span class="main-color-text total font-weight-bold cart-price"><?php echo e(Cart::instance('product')->total()); ?></span>
                        </div>
                    </div>

                    <ul class="shopping-cart-items w-100">
                        <?php
                            $content = Cart::instance('product')->content()
                        ?>
                        <?php if($content->count() > 0): ?>
                            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="cart-item d-flex w-100">
                                <div class="cart-image">
                                    <?php if($item->options->image): ?>
                                        <img src="<?php echo e(asset($item->options->image)); ?>" class="img-fluid" alt="">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('empty.jpg')); ?>" class="img-fluid" alt="">
                                    <?php endif; ?>
                                </div>
                                <div class="cart-detail ms-2 m-auto">
                                    <p><?php echo e($item->name); ?></p>
                                    <small>Qty: <span class="cart-qty"><?php echo e($item->qty); ?></span></small>
                                    <small class="ms-2">Price: £ <span class="cart-price"><?php echo e($item->price); ?></span></small>
                                </div>
                                <div class="cart-handler ms-auto">
                                    <span data-id="<?php echo e($item->rowId); ?>" style="cursor: pointer" class="remove-cart"><i class="far fa-times"></i></span>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="mt-3 mb--3 text-center">Cart is empty</p>
                        <?php endif; ?>

                    </ul>

                    <div class="shopping-cart-footer">
                        <?php if(Cart::instance('product')->content()->count() > 0): ?>
                            <a href="<?php echo e(route('cart')); ?>" class="button button-md text-center">View Cart</a>
                            <?php if(auth()->user()): ?>
                                <a href="<?php echo e(route('checkout')); ?>" class="button button-md text-center checkout-cart">Checkout</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="button button-md text-center checkout-cart">Checkout</a>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>

                </div>
                <button class="toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasmenu"
                    aria-controls="offcanvasmenu"><i class="fal fa-bars"></i></button>
            </div>
        </div>
    </div>
</header>

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasmenu" aria-labelledby="offcanvasmenuLabel">
    <div class="offcanvas-header">
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="offcanvas" aria-label="Close"><i
                class="fal fa-times"></i></button>
    </div>
    <div class="offcanvas-body">
        <div class="logo text-center justify-content-center m-auto">
            <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('theme/images/logo.png')); ?>" width="80px" class="img-fluid"
                    alt="Logo"></a>
        </div>
        <div class="offcanvas-navigation">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('products')); ?>">Products</a></li>
                <li><a href="">About</a></li>
                <li><a href="<?php echo e(route('booking.for.delivery')); ?>">Booking for delivery</a></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/front/components/header.blade.php ENDPATH**/ ?>