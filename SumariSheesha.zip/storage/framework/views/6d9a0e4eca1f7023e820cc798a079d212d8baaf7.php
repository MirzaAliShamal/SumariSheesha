<?php if($content->count() > 0): ?>
    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="cart-item d-flex w-100 mb-3">
        <div class="cart-image">
            <?php if(getBrandPrdDetails($item->id)->image): ?>
                <div style="height: 100px; width:100px">
                    <img src="<?php echo e(asset(getBrandPrdDetails($item->id)->image)); ?>" style="height: 100%; width:100%; object-fit:cover" class="img-fluid" alt="">
                </div>
            <?php else: ?>
                <div style="height: 100px; width:100px">
                    <img src="<?php echo e(asset('empty.jpg')); ?>" class="img-fluid" alt="">
                </div>
            <?php endif; ?>
        </div>
        <div class="cart-detail ms-2 m-auto">
            <p><?php echo e($item->name); ?></p>
            <small>Qty: <span class="cart-qty"><?php echo e($item->qty); ?></span></small>
            <small class="ms-2">Price: £ <span class="cart-price"><?php echo e($item->price); ?></span></small>
        </div>
        <div class="cart-handler ms-auto">
            <span data-id="<?php echo e($item->rowId); ?>" style="cursor: pointer" class="remove-booking"><i class="far fa-times"></i></span>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p class="mt-3 mb--3 text-center">Cart is empty</p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/ajax/booking.blade.php ENDPATH**/ ?>