<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-half d-table w-100 bg-page" style="background-image: url('<?php echo e(asset('theme/images/hero-bg.png')); ?>');">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 text-center">
                <h2>Products</h2>
            </div>
        </div>
    </div>
</section>

<section class="section bg-dark">
    <div class="container">
        <div class="row justify-content-center">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-sm-auto mb-4">
                    <div class="products">
                        <div class="card-image">
                            <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt="Product">
                        </div>
                        <div class="card-body">
                            <a href="<?php echo e(route('products', $item->slug)); ?>"><h4><?php echo e(Str::limit($item->name, 11, '...')); ?></h4></a>
                            <p><?php echo e(Str::limit($item->meta_description, 45, '...')); ?></p>
                        </div>
                    </div>
                    <div class="text-center">
                        <a href="" class="button button-md mt-4">Add To Cart</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/front/products.blade.php ENDPATH**/ ?>