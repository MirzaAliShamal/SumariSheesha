<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title'); ?> - Sumari Sheesha</title>

    
    <link rel="stylesheet" href="<?php echo e(asset('theme/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('theme/css/slick.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('theme/css/slick-theme.css')); ?>" type="text/css">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Reggae+One&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500&display=swap">
    <link rel="stylesheet" href="<?php echo e(asset('theme/fonts/css/all.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('theme/fonts/css/tabler-icons.css')); ?>" type="text/css">

    
    <link rel="stylesheet" href="<?php echo e(asset('theme/css/main.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('theme/css/responsive.css')); ?>" type="text/css">

    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <?php echo $__env->make('front.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('front.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script src="<?php echo e(asset('theme/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/js/main.js')); ?>"></script>

    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/layouts/front.blade.php ENDPATH**/ ?>