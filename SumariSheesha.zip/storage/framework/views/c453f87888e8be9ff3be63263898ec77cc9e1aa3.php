<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Zivi - Admin Dashboard Template</title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/app.min.css')); ?>">
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/components.css')); ?>">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/custom.css')); ?>">
    <link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('admin/img/favicon.ico')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin/bundles/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/app.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/bundles/prism/prism.css')); ?>">
    <style>

    </style>
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>
    <div class="loader"></div>
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <form id="logout-form" class="d-none" method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?></form>
            
            <?php echo $__env->make('admin.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            
            <?php echo $__env->make('admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
            
            <footer class="main-footer">
                <div class="footer-left">
                    Copyright &copy; 2019 <div class="bullet"></div> Design By <a href="#">Redstar</a>
                </div>
                <div class="footer-right">
                </div>
            </footer>
        </div>
    </div>
    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('admin/js/app.min.js')); ?>"></script>
    <!-- JS Libraies -->
    <script src="<?php echo e(asset('admin/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/amcharts4/core.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/amcharts4/charts.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/amcharts4/animated.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/bundles/prism/prism.js')); ?>"></script>
    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('admin/js/page/index.js')); ?>"></script>
    <!-- Template JS File -->
    <script src="<?php echo e(asset('admin/js/scripts.js')); ?>"></script>
    <!-- Custom JS File -->
    <script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>

    <script>
         var table = $('.datatables').DataTable({
                "sort": true,
                "ordering": true,
                "pagingType": "full_numbers",
                responsive: true,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search records",
                }
            });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/layouts/admin.blade.php ENDPATH**/ ?>