<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html"> <img alt="image" src="<?php echo e(asset('admin/img/logo.png')); ?>"
                    class="header-logo.png" /> <span class="logo-name">Zivi</span>
            </a>
        </div>
        <div class="sidebar-user">
            <div class="sidebar-user-picture">
                <img alt="image" src="<?php echo e(asset('admin/img/user.png')); ?>">
            </div>
            <div class="sidebar-user-details">
                <div class="user-name">Sarah Smith</div>
                <div class="user-role">Administrator</div>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown active">
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.dashboard')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                            <i data-feather="monitor"></i> Dashboard
                        </a>
                    </li>
                
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.flavour.*')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.flavour.list')); ?>">
                            <i data-feather="droplet"></i> Flavours
                        </a>
                    </li>
                
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.color.*')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.color.list')); ?>">
                            <i class="fa fa-brush"></i>  Colors
                        </a>
                    </li>
                
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.category.*')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.category.list')); ?>">
                            <i data-feather="layers"></i> Categories</a>
                        </li>
                
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.product.*')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.product.list')); ?>">
                            <i data-feather="box"></i> Products
                        </a>
                    </li>
                
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.brand.*')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.brand.list')); ?>">
                          <i data-feather="aperture"></i>  Brands
                        </a>
                    </li>
                
                
                    <li class=" <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.brand_product.*')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.brand_product.list')); ?>">
                            <i data-feather="box"></i>  Brand Products
                        </a>
                    </li>
                
            </li>

        </ul>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\SumariSheesha\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>